import networkx as nx
import matplotlib.pyplot as plt
from underground_map_data import nodes, edges

pos = {}
TubeGraph = nx.Graph()



for name, (zone, coord) in nodes.items():
    
    TubeGraph.add_node(name, zone=zone, coord=coord)
    pos[name] = coord

for source,target,lines in edges:
    TubeGraph.add_edge(source,target, lines=lines)

    
if __name__ == "__main__":
    nx.draw(TubeGraph, pos)
    plt.show()